Project Name: Timetracking

Technologies used:

1.Selenium Webdriver 3.4.0
2.Java 10
3.Cucumber
4.Maven

Introduction:

This project aims at logging absence for an employee working in BrightHR.The action is automated.

Steps to run the project:

git clone the project
Open the project in your IDE
Right click on Runner file in the src/test/java/com/interview/BrightHR

For output reports you can check the output folder
Project Details:

DriverFactory:

a.This is the BaseClass. b.This class contains the methods to initiaise the webdriver. c.This is where properties files are configured. An object of properties class is present in this class so that it can be invoked from child classes and the data is parameterized d.Also TestNG annotations like @BeforeMethod and @AfterMethod is made use before and after webdriver initialization

LocatorsAndActions:

a.This class is inherited from DriverFactory b.This is where Webelements and its actions are stored

Test Classes

LoginAndTimeOffSteps:

a. This test contains methods to login and log sickness absence

Configs

a. This is file created in src>main>java>com>interview>BrightHR>configs>config.properties b. This file has the details of the following selections:

browser
url
userName
password

All these parameters can be configured using this property file so that end user uses these tests just by changing values in this file. This helps in easy maintenance of the tests.