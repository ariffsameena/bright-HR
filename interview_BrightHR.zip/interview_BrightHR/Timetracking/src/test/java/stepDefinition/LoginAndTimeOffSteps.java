package stepDefinition;

import com.interview.BrightHR.LocatorsAndActions;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;

import java.util.NoSuchElementException;

public class LoginAndTimeOffSteps extends LocatorsAndActions{
    @Given("^User is on BrightHR page$")
    public void am_on_BrightHR_page() throws Exception {
        String expectedTitle = "Login - BrightHR";
        System.setProperty("webdriver.chrome.driver", "src/main/java/com/interview/configs/chromedriver.exe");
        System.setProperty("webdriver.gecko.driver", "src/main/java/com/interview/configs/geckodriver.exe");
        String browser = prop.getProperty("browser");
        if(browser.toUpperCase().equals("CHROME")){
            driver = new ChromeDriver();
        }
        switch (browser)
        {

            case "FIREFOX":
                driver = new FirefoxDriver();
            default:
                driver = new ChromeDriver();
        }
        driver.manage().window().maximize();
        driver.get(prop.getProperty("url"));
        Assert.assertEquals(pageTitle(),expectedTitle);
    }


    @Given("^User enters \"([^\"]*)\" and \"([^\"]*)\"$")
    public void user_enters_and(String username, String password) throws Throwable {
        userName().sendKeys(username);
        password().sendKeys(password);
    }
    @Then("^Clicking on login should allow user to login$")
    public void clicking_on_login_should_allow_user_to_login() throws Exception {
       loginButton().click();
    }

    @Given("^am on BrightHR Home page$")
    public void am_on_BrightHR_Home_page() throws Exception {
        try {
            logoutButton().isDisplayed();
        }
        catch (NoSuchElementException e) {
            throw new RuntimeException("We are in wrong page");
        }
    }
    @When("^Click on absence$")
    public void click_on_absence() throws Exception {
        Thread.sleep(10000);
        addSickLeaveButton().click();
        Thread.sleep(10000);
        addTimeOffButton().click();
    }
    @Then("^Inputting absence details should allow me to take time off$")
    public void inputting_absence_details_should_allow_me_to_take_time_off() throws Exception {
        Thread.sleep(10000);
        absencyTypeField().selectByIndex(7);
        Thread.sleep(5000);
        startDateField().sendKeys("20/07/2018");
        Thread.sleep(5000);
        endDateField().sendKeys("20/07/2018");
        detailsField().sendKeys("sickness");
        addAbsenceConfirmationButton().click();
        if(profileButton().isDisplayed()){
            Assert.assertTrue(true);
            driver.manage().deleteAllCookies();
            driver.quit();
        }
    }
}
