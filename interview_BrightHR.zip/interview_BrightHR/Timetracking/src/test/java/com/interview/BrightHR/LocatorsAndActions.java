package com.interview.BrightHR;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;



public class LocatorsAndActions extends DriverFactory{

    public WebElement userName() throws Exception {
        return driver.findElement(By.name("username"));
    }

    public WebElement password() throws Exception {
        return driver.findElement(By.name("password"));

               }

    public WebElement loginButton() throws Exception {
        return driver.findElement(By.id("loginBtn"));
    }


    public WebElement addSickLeaveButton() throws Exception {
        return driver.findElement(By.xpath("//button[@class = 'sc-fBuWsC eFHAdD']"));
    }

    public WebElement addTimeOffButton() throws Exception {
        return driver.findElement(By.xpath("//a[@data-e2e='request-time-off-btn']"));
    }

    public Select absencyTypeField() throws Exception{

        Select absenceType = new Select(driver.findElement(By.id("absenceTypeSelect")));
        return absenceType;
    }


    public WebElement startDateField() throws Exception {
        return driver.findElement(By.id("start-date"));
    }

    public WebElement endDateField() throws Exception {
        return driver.findElement(By.id("end-date"));
    }

    public WebElement detailsField() throws Exception {
        return driver.findElement(By.id("details"));
    }

    public WebElement addAbsenceConfirmationButton() throws Exception {
        return driver.findElement(By.xpath("//button[@id = 'requestSickness']"));
    }

    public String pageTitle() throws Exception {
        String actualTitle = driver.getTitle();
        return actualTitle;
    }

    public WebElement logoutButton() throws Exception {
        return driver.findElement(By.xpath("//button[contains(text(),Logout)]"));
    }

    public WebElement profileButton() throws Exception {
        return driver.findElement(By.id("confirm"));
    }

    }

