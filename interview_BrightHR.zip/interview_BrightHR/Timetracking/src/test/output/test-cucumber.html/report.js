$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("Login.feature");
formatter.feature({
  "line": 1,
  "name": "Login",
  "description": "",
  "id": "login",
  "keyword": "Feature"
});
formatter.background({
  "line": 3,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 4,
  "name": "User is on BrightHR page",
  "keyword": "Given "
});
formatter.match({
  "location": "LoginAndTimeOffSteps.am_on_BrightHR_page()"
});
formatter.result({
  "duration": 32224489010,
  "status": "passed"
});
formatter.scenario({
  "line": 6,
  "name": "Logging in",
  "description": "",
  "id": "login;logging-in",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 7,
  "name": "User enters \"Tech_test@grr.la\" and \"123456\"",
  "keyword": "And "
});
formatter.step({
  "line": 8,
  "name": "Clicking on login should allow user to login",
  "keyword": "Then "
});
formatter.match({
  "arguments": [
    {
      "val": "Tech_test@grr.la",
      "offset": 13
    },
    {
      "val": "123456",
      "offset": 36
    }
  ],
  "location": "LoginAndTimeOffSteps.user_enters_and(String,String)"
});
formatter.result({
  "duration": 331079048,
  "status": "passed"
});
formatter.match({
  "location": "LoginAndTimeOffSteps.clicking_on_login_should_allow_user_to_login()"
});
formatter.result({
  "duration": 80636617,
  "status": "passed"
});
formatter.uri("TimeOff.feature");
formatter.feature({
  "line": 1,
  "name": "TimeOff",
  "description": "",
  "id": "timeoff",
  "keyword": "Feature"
});
formatter.background({
  "line": 3,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 4,
  "name": "am on BrightHR Home page",
  "keyword": "Given "
});
formatter.match({
  "location": "LoginAndTimeOffSteps.am_on_BrightHR_Home_page()"
});
formatter.result({
  "duration": 64482939,
  "status": "passed"
});
formatter.scenario({
  "line": 6,
  "name": "Taking TimeOff",
  "description": "",
  "id": "timeoff;taking-timeoff",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 7,
  "name": "Click on absence",
  "keyword": "When "
});
formatter.step({
  "line": 8,
  "name": "Inputting absence details should allow me to take time off",
  "keyword": "Then "
});
formatter.match({
  "location": "LoginAndTimeOffSteps.click_on_absence()"
});
formatter.result({
  "duration": 20343394236,
  "status": "passed"
});
formatter.match({
  "location": "LoginAndTimeOffSteps.inputting_absence_details_should_allow_me_to_take_time_off()"
});
formatter.result({
  "duration": 22637444273,
  "status": "passed"
});
});